import { useState } from "react";
import "./App.css";
import ProductManagementApp from "./pages/ProductPage";

function App() {
  return (
    <>
      <ProductManagementApp />
    </>
  );
}

export default App;
